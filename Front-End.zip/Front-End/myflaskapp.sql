-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2020 at 01:33 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myflaskapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Sl.no` int(100) NOT NULL,
  `p_id` int(11) NOT NULL,
  `image` varchar(200) NOT NULL,
  `result` varchar(100) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Sl.no`, `p_id`, `image`, `result`, `date_time`) VALUES
(1, 25, 'C:/flask1/static/image_uploads/p25_T_14-06-2020_21-07-08.jpg', 'TUMOR', '2020-06-14 21:07:08'),
(2, 25, 'C:/flask1/static/image_uploads/p25_N_14-06-2020_21-08-48.jpg', 'NORMAL', '2020-06-14 21:08:48'),
(3, 25, 'C:/flask1/static/image_uploads/p25_N_14-06-2020_21-12-03.jpg', 'NORMAL', '2020-06-14 21:12:03'),
(4, 25, 'C:/flask1/static/image_uploads/p25_N_14-06-2020_21-13-45.jpg', 'NORMAL', '2020-06-14 21:13:45'),
(5, 25, 'C:/flask1/static/image_uploads/p25_T_14-06-2020_21-15-26.jpg', 'TUMOR', '2020-06-14 21:15:26'),
(6, 25, 'C:/flask1/static/image_uploads/p25_T_14-06-2020_21-16-43.jpg', 'TUMOR', '2020-06-14 21:16:43'),
(7, 25, 'C:/flask1/static/image_uploads/p25_T_14-06-2020_21-28-08.jpg', 'TUMOR', '2020-06-14 21:28:08'),
(8, 25, 'C:/flask1/static/image_uploads/p25_T_14-06-2020_21-31-46.jpg', 'TUMOR', '2020-06-14 21:31:46'),
(9, 25, 'C:/flask1/static/image_uploads/p25_14-06-2020_21-44-21.jpg', 'TUMOR', '2020-06-14 21:44:27'),
(10, 25, 'C:/flask1/static/image_uploads/p25_T_15-06-2020_10-58-08.jpg', 'TUMOR', '2020-06-15 10:58:08'),
(11, 11, 'C:/flask1/static/image_uploads/p11_N_15-06-2020_11-03-43.jpg', 'NORMAL', '2020-06-15 11:03:43'),
(12, 11, 'C:/flask1/static/image_uploads/p11_N_15-06-2020_11-28-42.jpg', 'NORMAL', '2020-06-15 11:28:42'),
(13, 26, 'C:/flask1/static/image_uploads/p26_N_15-06-2020_12-50-14.jpg', 'NORMAL', '2020-06-15 12:50:14'),
(14, 27, 'C:/flask1/static/image_uploads/p27_N_15-06-2020_13-16-45.jpg', 'NORMAL', '2020-06-15 13:16:45'),
(15, 28, 'C:/flask1/static/image_uploads/p28_T_15-06-2020_22-06-42.jpg', 'TUMOR', '2020-06-15 22:06:42'),
(16, 29, 'C:/flask1/static/image_uploads/p29_T_15-06-2020_22-26-31.jpg', 'TUMOR', '2020-06-15 22:26:31'),
(17, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_00-15-38.jpg', 'TUMOR', '2020-06-16 00:15:38'),
(18, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_18-33-50.jpg', 'TUMOR', '2020-06-16 18:33:50'),
(19, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_18-35-54.jpg', 'TUMOR', '2020-06-16 18:35:54'),
(20, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_18-38-01.jpg', 'TUMOR', '2020-06-16 18:38:01'),
(21, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_18-38-55.jpg', 'TUMOR', '2020-06-16 18:38:55'),
(22, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_18-50-04.jpg', 'TUMOR', '2020-06-16 18:50:04'),
(23, 24, 'C:/flask1/static/image_uploads/p24_T_16-06-2020_20-46-14.jpg', 'TUMOR', '2020-06-16 20:46:14'),
(24, 24, 'C:/flask1/static/image_uploads/p24_T_17-06-2020_12-10-59.jpg', 'TUMOR', '2020-06-17 12:10:59'),
(25, 31, 'C:/flask1/static/image_uploads/p31_T_17-06-2020_14-50-44.jpg', 'TUMOR', '2020-06-17 14:50:44'),
(26, 31, 'C:/flask1/static/image_uploads/p31_N_17-06-2020_14-51-16.jpg', 'NORMAL', '2020-06-17 14:51:16'),
(27, 24, 'C:/flask1/static/image_uploads/p24_N_18-06-2020_11-51-31.jpg', 'NORMAL', '2020-06-18 11:51:31'),
(28, 24, 'C:/flask1/static/image_uploads/p24_T_18-06-2020_11-55-33.jpg', 'TUMOR', '2020-06-18 11:55:33'),
(29, 31, 'C:/flask1/static/image_uploads/p31_T_18-06-2020_11-55-57.jpg', 'TUMOR', '2020-06-18 11:55:57'),
(30, 31, 'C:/flask1/static/image_uploads/p31_T_18-06-2020_13-51-22.jpg', 'TUMOR', '2020-06-18 13:51:23'),
(31, 33, 'C:/flask1/static/image_uploads/p33_T_18-06-2020_15-08-24.jpg', 'TUMOR', '2020-06-18 15:08:24'),
(32, 24, 'C:/flask1/static/image_uploads/p24_T_18-06-2020_17-33-30.jpg', 'TUMOR', '2020-06-18 17:33:31'),
(33, 24, 'C:/flask1/static/image_uploads/p24_T_19-07-2020_16-47-20.jpg', 'TUMOR', '2020-07-19 16:47:20'),
(34, 24, 'C:/flask1/static/image_uploads/p24_N_19-07-2020_16-48-01.jpg', 'NORMAL', '2020-07-19 16:48:02'),
(35, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-02-13.jpg', 'TUMOR', '2020-07-26 15:02:14'),
(36, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-02-52.jpg', 'TUMOR', '2020-07-26 15:02:52'),
(37, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-03-51.jpg', 'TUMOR', '2020-07-26 15:03:51'),
(38, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-04-27.jpg', 'TUMOR', '2020-07-26 15:04:27'),
(39, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-04-54.jpg', 'TUMOR', '2020-07-26 15:04:54'),
(40, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-05-20.jpg', 'TUMOR', '2020-07-26 15:05:20'),
(41, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-05-44.jpg', 'TUMOR', '2020-07-26 15:05:44'),
(42, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_15-06-06.jpg', 'NORMAL', '2020-07-26 15:06:06'),
(43, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_15-06-30.jpg', 'NORMAL', '2020-07-26 15:06:30'),
(44, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_15-06-53.jpg', 'NORMAL', '2020-07-26 15:06:53'),
(45, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_15-07-32.jpg', 'NORMAL', '2020-07-26 15:07:32'),
(46, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_15-08-01.jpg', 'NORMAL', '2020-07-26 15:08:01'),
(47, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-08-42.jpg', 'TUMOR', '2020-07-26 15:08:42'),
(48, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-14-59.jpg', 'TUMOR', '2020-07-26 15:14:59'),
(49, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-15-21.jpg', 'TUMOR', '2020-07-26 15:15:21'),
(50, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-15-39.jpg', 'TUMOR', '2020-07-26 15:15:39'),
(51, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-16-25.jpg', 'TUMOR', '2020-07-26 15:16:25'),
(52, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-17-35.jpg', 'TUMOR', '2020-07-26 15:17:35'),
(53, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-49-51.jpg', 'TUMOR', '2020-07-26 15:49:51'),
(54, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-50-15.jpg', 'TUMOR', '2020-07-26 15:50:15'),
(55, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-50-51.jpg', 'TUMOR', '2020-07-26 15:50:51'),
(56, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-51-12.jpg', 'TUMOR', '2020-07-26 15:51:12'),
(57, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-51-23.jpg', 'TUMOR', '2020-07-26 15:51:23'),
(58, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-51-35.jpg', 'TUMOR', '2020-07-26 15:51:35'),
(59, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-51-49.jpg', 'TUMOR', '2020-07-26 15:51:49'),
(60, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-52-01.jpg', 'TUMOR', '2020-07-26 15:52:01'),
(61, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-52-16.jpg', 'TUMOR', '2020-07-26 15:52:16'),
(62, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-52-25.jpg', 'TUMOR', '2020-07-26 15:52:25'),
(63, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-52-41.jpg', 'TUMOR', '2020-07-26 15:52:41'),
(64, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-53-04.jpg', 'TUMOR', '2020-07-26 15:53:04'),
(65, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-53-16.jpg', 'TUMOR', '2020-07-26 15:53:16'),
(66, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-53-28.jpg', 'TUMOR', '2020-07-26 15:53:28'),
(67, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-53-40.jpg', 'TUMOR', '2020-07-26 15:53:40'),
(68, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-53-57.jpg', 'TUMOR', '2020-07-26 15:53:57'),
(69, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-54-10.jpg', 'TUMOR', '2020-07-26 15:54:10'),
(70, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-54-24.jpg', 'TUMOR', '2020-07-26 15:54:24'),
(71, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-54-41.jpg', 'TUMOR', '2020-07-26 15:54:41'),
(72, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-54-54.jpg', 'TUMOR', '2020-07-26 15:54:54'),
(73, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-55-07.jpg', 'TUMOR', '2020-07-26 15:55:07'),
(74, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-55-24.jpg', 'TUMOR', '2020-07-26 15:55:24'),
(75, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-55-42.jpg', 'TUMOR', '2020-07-26 15:55:42'),
(76, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-56-01.jpg', 'TUMOR', '2020-07-26 15:56:01'),
(77, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-56-15.jpg', 'TUMOR', '2020-07-26 15:56:15'),
(78, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-56-29.jpg', 'TUMOR', '2020-07-26 15:56:29'),
(79, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-56-47.jpg', 'TUMOR', '2020-07-26 15:56:47'),
(80, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-57-02.jpg', 'TUMOR', '2020-07-26 15:57:02'),
(81, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-57-27.jpg', 'TUMOR', '2020-07-26 15:57:28'),
(82, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-57-50.jpg', 'TUMOR', '2020-07-26 15:57:51'),
(83, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-58-05.jpg', 'TUMOR', '2020-07-26 15:58:05'),
(84, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-58-21.jpg', 'TUMOR', '2020-07-26 15:58:21'),
(85, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-59-29.jpg', 'TUMOR', '2020-07-26 15:59:29'),
(86, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_15-59-48.jpg', 'TUMOR', '2020-07-26 15:59:49'),
(87, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-00-04.jpg', 'TUMOR', '2020-07-26 16:00:04'),
(88, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-00-19.jpg', 'TUMOR', '2020-07-26 16:00:19'),
(89, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-00-48.jpg', 'TUMOR', '2020-07-26 16:00:48'),
(90, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-03-16.jpg', 'TUMOR', '2020-07-26 16:03:16'),
(91, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-03-55.jpg', 'TUMOR', '2020-07-26 16:03:55'),
(92, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-04-30.jpg', 'TUMOR', '2020-07-26 16:04:30'),
(93, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-05-15.jpg', 'TUMOR', '2020-07-26 16:05:16'),
(94, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-05-59.jpg', 'TUMOR', '2020-07-26 16:06:01'),
(95, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-56-09.jpg', 'TUMOR', '2020-07-26 16:56:09'),
(96, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_16-57-13.jpg', 'TUMOR', '2020-07-26 16:57:13'),
(97, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_17-05-27.jpg', 'NORMAL', '2020-07-26 17:05:28'),
(98, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_17-05-27.jpg', 'NORMAL', '2020-07-26 17:05:28'),
(99, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_17-08-16.jpg', 'NORMAL', '2020-07-26 17:08:16'),
(100, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_17-24-14.jpg', 'TUMOR', '2020-07-26 17:24:14'),
(101, 24, 'C:/flask1/static/image_uploads/p24_T_26-07-2020_17-25-46.jpg', 'TUMOR', '2020-07-26 17:25:46'),
(102, 24, 'C:/flask1/static/image_uploads/p24_N_26-07-2020_17-26-08.jpg', 'NORMAL', '2020-07-26 17:26:08');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `token` varchar(500) NOT NULL,
  `email` varchar(100) NOT NULL,
  `time_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`token`, `email`, `time_created`) VALUES
('966FE6653C684D8F8A855789597042FF', 'gglusr95@gmail.com', '2020-06-19 18:41:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(3) NOT NULL,
  `register_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `age`, `register_date`) VALUES
(11, 'admin', 'admin@gmail.com', '$5$rounds=535000$0SiK077ynv12GTh3$6u.flHq.obm9rGbsEzKYXkTuHSk0s15W2A8VOVwQEUB', 'Male', 54, '2020-06-07 07:03:30'),
(13, 'admin1@m', 'admin1@gmail.com', '$5$rounds=535000$kHtxeUsAjkCkZDgV$Y4CBsBCxHvrMwFgRSUaaJ2O7eGSs3mbgDsDs6YN.i76', 'Male', 51, '2020-06-07 07:06:34'),
(14, 'uib', 'ugug@jbs.ajnk', '$5$rounds=535000$gItyKemtNXv8Mksq$0XXDUbm0UmuG3dK2HOM5nbRq56I7gEiwXRNrLsmwL85', 'Male', 53, '2020-06-07 07:47:54'),
(15, 'kjnn', 'jjj@jndk.cn', '$5$rounds=535000$RAwjcW4tnTkgnRdG$zRHBnChHj974Xj74Ntw.EzLGkXnJlLL8f81Bigm5BJ.', 'Male', 52, '2020-06-07 09:54:51'),
(16, 'jbb', 'kn@knd.cjb', '$5$rounds=535000$3xDnO3KKz1VeA4Vi$AZNsEG8SLprj.2cnrwW7F3qZhnDvD8g7tg2k1otEG15', 'Male', 51, '2020-06-07 10:40:03'),
(17, 'admin2', 'admin2@gmail.com', '$5$rounds=535000$yJY2YghEv6BD9mw5$EJJiBGeGmzUoVedxvIE0aBznwbtqnmQIM1EbvcPA7zC', 'Male', 55, '2020-06-07 10:56:36'),
(18, 'patient2', 'patient2@gmail.com', '$5$rounds=535000$taJFXHcDaqmLedlg$kVXwQ6vEBpiRw.U6fme0ZmHMoYHpk5c8E2BBLNhcNE.', 'Female', 51, '2020-06-10 16:49:05'),
(19, 'abcde', 'abc@gm.c', '$5$rounds=535000$jtW93wq3.YvZaYWw$1yWndCbybFI.dnuC.upEkQnbylu/AeIAxgsPwzrdqK7', 'Male', 59, '2020-06-12 12:01:34'),
(20, 'uvaaav', 'yauva@nss.sis', '$5$rounds=535000$lLDm0flgszkFWK/M$0TEoDsKrYcjJChYXqdrqFoBcMuyvqrhbuTNGwmz3Jg4', 'Male', 25, '2020-06-12 15:10:37'),
(21, '   aa', 'aa@aa.aa', '$5$rounds=535000$In9zotIpXoVobkwD$mLu24uppt0xEc6CZ21C/Ivevatn1uj013PPnrwqDKdD', 'Female', 1, '2020-06-12 18:52:06'),
(23, 'mmmmm', 'm@m.m', '$5$rounds=535000$fJgdyWrSMQQFc.lX$w03t8VouI6EZmCoi2KwDk6qXkOT8u4DG7mrX1B1OMQ7', 'Female', 36, '2020-06-12 19:03:57'),
(24, 'Sachin', 'gglusr95@gmail.com', '$5$rounds=535000$K85HQKlbwP2kcqyT$PzT7ARwDpbain3aUAY7S9XGsNSkRtKTpwwAyCYFclH6', 'Male', 88, '2020-06-12 19:25:04'),
(25, 'abcde', 'abcde@gmail.com', '$5$rounds=535000$lTp3lD1KpGOfyheu$a1FUktRlrj1zIsaxAj7sGVXGSRcY6NFQW44NTfy7HN.', 'Male', 66, '2020-06-14 14:59:18'),
(26, 'Raju', 'raju@gmail.com', '$5$rounds=535000$9d/RRLqwmlTGu92F$UQNBeVFr7yuNMbYTQP8J9ZJzOB3ZGfMBRhTMkUW6js0', 'Male', 25, '2020-06-15 07:19:01'),
(27, 'Patient', 'patient@gmail.com', '$5$rounds=535000$zQOm/e2YQ4dMzFrH$jvJvTfWdV2WtR/42S5h0oQTT8E7a151TsTmeGpnG/G1', 'Male', 55, '2020-06-15 07:43:56'),
(28, 'Rahul', 'rahul@gmail.com', '$5$rounds=535000$OMx30xM7oAHvFnBH$HbDDmemcqtxOjgMTHIXhC5xRx4bx4FOm7993BcWFFjC', 'Male', 36, '2020-06-15 16:35:28'),
(29, 'bbbbb', 'bbbbb@gmail.com', '$5$rounds=535000$IJSW.uZL2vdfq/Tg$gx7X04odqxGorB1uXZejrNE.RM.rM5aP7WnUlFsiFRB', 'Male', 90, '2020-06-15 16:55:59'),
(30, 'ugihu', 'ajn@kmd.dj', '$5$rounds=535000$4Sl7XMd5qnzVjgnX$Wgh6OA7zpI5RjfE3LNhZNC.AoAE1VdLg3lFCMbIxm10', 'Male', 55, '2020-06-16 09:22:49'),
(31, 'Sumanth', 'sumanth@gmail.com', '$5$rounds=535000$/lRpf9XH4QMV8T77$ABlMZRyY7WOGwEmUWUR/ZS2kJzdWoTPE.ifMntcLcC2', 'Male', 36, '2020-06-17 09:19:07'),
(32, 'bjhjb', 'p@p.p', '$5$rounds=535000$UEKrpfq522k64nM7$kKiOmoSi3mqIsNMdL/kEG.I7ov9xAQUyk7p0Z6uSiDA', 'default', 23, '2020-06-18 07:52:47'),
(33, 'guh', 'p@p.pq', '$5$rounds=535000$0/ywbb14uTNQkZs6$OzffXePGCKLAlepdfdVn6DWxPobMN7rrg8qb0gNvsUB', 'Male', 44, '2020-06-18 09:37:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Sl.no`),
  ADD KEY `fk1` (`p_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `Sl.no` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk1` FOREIGN KEY (`p_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
