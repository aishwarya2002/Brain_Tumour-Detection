from flask import Flask, render_template, flash, redirect, url_for, session, request, logging
from flask_mysqldb import MySQL
from wtforms import Form, StringField, PasswordField, validators, IntegerField, SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, Regexp
from passlib.hash import sha256_crypt
from functools import wraps
from skimage import transform
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import cv2
import imutils
from PIL import ImageEnhance
import imageio
import datetime
from flask import jsonify, request, render_template
from flask_mail import Message, Mail
from flask_wtf import FlaskForm
import uuid
from itsdangerous import SignatureExpired

app = Flask(__name__)

# Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'myflaskapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# init MYSQL
mysql = MySQL(app)

app.config['MAIL_SERVER'] = 'smtp.googlemail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'braintumordetectorapp@gmail.com'
app.config['MAIL_PASSWORD'] = 'brain123@'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)


# Index
@app.route('/')
def index():
    session.clear()
    return render_template('home.html')


@app.route('/home')
def home():
    return render_template('home.html')


# About
@app.route('/about')
def about():
    return render_template('about.html')


# Register Form Class
class RegisterForm(Form):
    name = StringField('Full Name',
                       validators=[Length(min=3, max=40, message='Enter your full name(min 3 char!)'), DataRequired(),
                                   Regexp('^[A-Za-z]{3,20}([. ]?[A-Za-z]+){0,3}$',
                                          message='No numbers/special characters allowed except . and space!! (min 3 char in First name)')],
                       render_kw={'autofocus': True})
    # username = StringField('Username', validators=[Length(min=5, max=15), DataRequired()])
    email = StringField('Email',
                        validators=[Length(min=5, max=50), Email(message='Enter a valid email!'), DataRequired(),
                                    Regexp('^[A-Za-z0-9_]{1,}(\.[A-Za-z0-9_]+)*@[A-Za-z]{1,15}[.]{1}[A-Za-z]{1,5}(\.[A-Za-z]{1,5})*$',
                                           message='(Special charcters like . and _ only allowed!)')])
    password = PasswordField('Password', validators=[DataRequired(),
                                                     Length(min=5, max=16,
                                                            message='Select a stronger password (min 5 char)!')])
    confirm = PasswordField('Confirm Password',
                            validators=[DataRequired(),
                                        Length(min=5, max=16, message='Select a stronger password (min 5 char)!'),
                                        EqualTo('password', message='Password and Confirm Password not matching!')])
    # gender = RadioField('Gender', choices=[('M', 'Male'), ('F', 'Female')], validators=[DataRequired()])
    gender = SelectField('Gender', choices=[('', 'Select your Gender'), ('Male', 'Male'), ('Female', 'Female')], validators=[DataRequired()])
    age = IntegerField('Age', validators=[NumberRange(min=0, max=100, message='Enter a no. from 0-100 only!'),
                                          DataRequired(message='Enter valid age!')])


# User Register
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        name = form.name.data
        email = form.email.data
        # username = form.username.data
        gender = form.gender.data
        age = form.age.data
        password = sha256_crypt.encrypt(str(form.password.data))

        # Create cursor
        cur = mysql.connection.cursor()

        # Execute query
        cur.execute("INSERT INTO users(name, email, password, gender, age) VALUES(%s, %s, %s, %s, %s)",
                    (name, email, password, gender, age))

        # Commit to DB
        mysql.connection.commit()

        # Close connection
        cur.close()

        flash('You are now registered and can log in', 'success')

        return redirect(url_for('login'))
    return render_template('register.html', form=form)


# User login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get Form Fields
        email = request.form['email']
        password_candidate = request.form['password']

        # Create cursor
        cur = mysql.connection.cursor()

        # Get user by username
        result = cur.execute("SELECT * FROM users WHERE email = %s", [email])
        if result > 0:
            # Get stored hash
            data = cur.fetchone()
            password = data['password']
            username = data['name']
            global patient_id
            patient_id = data['id']

            # Compare Passwords
            if sha256_crypt.verify(password_candidate, password):
                # Passed
                session['logged_in'] = True
                session['username'] = username

                flash('You are now logged in!', 'success')
                return redirect(url_for('dashboard'))
                # return render_template('upload.html')
            else:
                error = 'Invalid login credentials!'
                return render_template('login.html', error=error)
            # Close connection
            cur.close()
        else:
            error = 'Email not registered!'
            return render_template('login.html', error=error)

    return render_template('login.html')


# Check if user logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized Access, Please login!', 'danger')
            return redirect(url_for('login'))

    return wrap


# Logout
@app.route('/logout')
@is_logged_in
def logout():
    session.clear()
    flash('You are now logged out!', 'success')
    return redirect(url_for('login'))


# Dashboard
@app.route('/dashboard')
@is_logged_in
def dashboard():
    # Create cursor
    cur = mysql.connection.cursor()
    return render_template('upload.html')

    cur.close()


def background_cropping(image, plot=False):
    # Image thresholding
    thresh = cv2.threshold(image, 45, 255, cv2.THRESH_BINARY)[1]
    thresh = cv2.erode(thresh, None, iterations=2)  # erosions and dilations to remove any small regions of noise
    thresh = cv2.dilate(thresh, None, iterations=2)
    # Finding largest contour in image
    cnts = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # returns a numpy array of x,y coordinate
    cnts = imutils.grab_contours(cnts)
    c = max(cnts, key=cv2.contourArea)
    # Locate extreme points
    extLeft = tuple(c[c[:, :, 0].argmin()][0])
    extRight = tuple(c[c[:, :, 0].argmax()][0])
    extTop = tuple(c[c[:, :, 1].argmin()][0])
    extBot = tuple(c[c[:, :, 1].argmax()][0])
    # Using above extreme points, crop image
    new_image = image[extTop[1]:extBot[1], extLeft[0]:extRight[0]]
    return new_image


def load(filename):
    # display original image
    img0 = cv2.imread(filename, cv2.IMREAD_GRAYSCALE)
    cv2.namedWindow('Original Test Image', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('Original Test Image', 300, 300)
    cv2.imshow('Original Test Image', img0)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # grayscale-resize
    img1 = Image.open(filename).convert('L')  # grayyscale
    img2 = img1.resize((380, 380), Image.ANTIALIAS)
    img2.save("resized.jpg")
    img3 = cv2.imread("resized.jpg", cv2.IMREAD_GRAYSCALE)
    cv2.imshow('Resized/Grayscale', img3)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # gaussian filter
    img4 = cv2.imread("resized.jpg", cv2.IMREAD_GRAYSCALE)  # reads the image
    figure_size = 9  # the dimension of the x and y axis of the kernal.
    new_image_gauss = cv2.GaussianBlur(img4, (figure_size, figure_size), 0)
    img5 = Image.fromarray(new_image_gauss)
    img5.save("filter.jpg")
    cv2.imshow('Gaussian Filter', new_image_gauss)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # crop
    img6 = cv2.imread("filter.jpg", cv2.IMREAD_GRAYSCALE)
    crop_img = background_cropping(img6, True)
    resize_img = cv2.resize(crop_img, (380, 380))
    img7 = Image.fromarray(resize_img)
    img7.save("cropped.jpg")
    cv2.imshow('Cropped', resize_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # enhance1
    img8 = Image.open("cropped.jpg")
    enh_bri = ImageEnhance.Brightness(img8)
    brightness = 1.3
    image_brightened = enh_bri.enhance(brightness)
    enh_col = ImageEnhance.Color(image_brightened)
    color = 1.5
    image_colored = enh_col.enhance(color)
    enh_con = ImageEnhance.Contrast(image_colored)
    contrast = 1.3
    image_contrasted = enh_con.enhance(contrast)
    enh_sha = ImageEnhance.Sharpness(image_contrasted)
    sharpness = 3.0
    image_sharped = enh_sha.enhance(sharpness)
    image_sharped.save("enhanced1.jpg")
    img9 = cv2.imread("enhanced1.jpg", cv2.IMREAD_GRAYSCALE)
    cv2.imshow('Enhanced-1', img9)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # enhance2
    img10 = imageio.imread("enhanced1.jpg")
    img10 = img10 / 255.0
    im_power_law_transformation = cv2.pow(img10, 1.5)
    img11 = Image.fromarray(np.uint8(im_power_law_transformation * 255))
    img12 = img11.convert("L")
    img12.save("enhanced2.jpg")
    img13 = cv2.imread("enhanced2.jpg", cv2.IMREAD_GRAYSCALE)
    cv2.imshow('Enhanced-2', img13)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # converting to array for giving to model
    np_image = Image.open("enhanced2.jpg")
    np_image = np.array(np_image).astype('float32') / 255
    np_image = transform.resize(np_image, (380, 380, 1))
    np_image = np.expand_dims(np_image, axis=0)
    return np_image


@app.route('/result', methods=['GET', 'POST'])
@is_logged_in
def result():
    model = load_model('C:/Users/User1/Desktop/BT_Detection/Back-End/brain01aa.h5')
    data = request.files["file"]
    data.save("C:/flask1/static/testimage.jpg")
    image = load('C:/flask1/static/testimage.jpg')  # tumor image
    pred = model.predict(image)
    if pred.item() > 0.5:
        print('TUMOR!!')
        result1 = "This image has a TUMOR!!"
        result2 = "TUMOR"
        res = "T"
    else:
        print('NO TUMOR!!')
        result1 = "This image DOES NOT HAVE TUMOR!!"
        result2 = "NORMAL"
        res = "N"

    dt = datetime.datetime.now()
    date = dt.strftime("%d")
    month = dt.strftime("%m")
    year = dt.strftime("%Y")
    hr = dt.strftime("%H")
    mint = dt.strftime("%M")
    sec = dt.strftime("%S")

    img01 = cv2.imread("C:/flask1/static/testimage.jpg", -1)
    filename1 = "C:/flask1/static/image_uploads/p%d_%s_%s-%s-%s_%s-%s-%s.jpg" % (patient_id, res, date, month, year, hr, mint, sec)
    cv2.imwrite(filename1, img01)

    cur = mysql.connection.cursor()
    cur.execute("INSERT INTO patient(p_id,image, result) VALUES(%s, %s, %s)", (patient_id, filename1, result2))
    mysql.connection.commit()
    cur.close()

    return render_template('result.html', result=result1)


@app.route('/user_check', methods=['GET', 'POST'])
def user_check():
    try:
        email = request.form['email']

        # validate the received values
        if email and request.method == 'POST':
            cur = mysql.connection.cursor()
            results = cur.execute("SELECT * FROM users WHERE email = %s", [email])

            if results > 0:
                row = cur.fetchone()
                resp = jsonify('<span style=\'color:red;\'>Email is already registered! Use a different mail!</span>')
                resp.status_code = 200
                return resp
            else:
                resp = jsonify('<span style=\'color:green;\'>Email not registered! You can proceed.</span>')
                resp.status_code = 200
                return resp
        else:
            resp = jsonify('<span style=\'color:red;\'>Enter a valid Email!</span>')
            resp.status_code = 200
            return resp
    except Exception as e:
        print(e)
    finally:
        cur.close()
        # conn.close()


@app.after_request
def add_header(response):
    response.headers['Pragma'] = 'no-cache'
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Expires'] = '0'
    return response


class ResetForm(FlaskForm):
    email = StringField('Email',
                        validators=[Length(min=5, max=50), Email(message=' Enter a valid email!'), DataRequired(),
                                    Regexp('^[A-Za-z0-9_]{1,}(\.[A-Za-z0-9_]+)*@[A-Za-z]{1,15}[.]{1}[A-Za-z]{1,5}(\.[A-Za-z]{1,5})*$',
                                           message='(Special charcters like . and _ only allowed!)')])


class PasswordForm(FlaskForm):
    email = StringField('Email',
                        validators=[Length(min=5, max=50), Email(message=' Enter a valid email!'), DataRequired(),
                                    Regexp('^[A-Za-z0-9_]{1,}(\.[A-Za-z0-9_]+)*@[A-Za-z]{1,15}[.]{1}[A-Za-z]{1,5}(\.[A-Za-z]{1,5})*$',
                                           message='(Special charcters like . and _ only allowed!)')])
    password = PasswordField('Password', validators=[DataRequired(),
                                                     Length(min=5, max=16, message='Select a stronger password (5-16 char)!')])
    confirm = PasswordField('Confirm Password',
                            validators=[DataRequired(), EqualTo('password', message='Password and Confirm Password not matching!')])


# @app.route('/pass_form/<token>/<email>')
@app.route('/pass_form/<token>')
def pass_form(token):
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM token WHERE time_created < (NOW() - INTERVAL 2 MINUTE )")
    mysql.connection.commit()
    results = cur.execute("SELECT * FROM token WHERE token = %s and email = %s", [token, reset_email])
    if results > 0:
        data = cur.fetchone()
        print("c1=", reset_email)
        return redirect(url_for('password_confirm'))
    else:
        flash('Password reset link Expired!! Resend Link and use it within 2 minutes.', 'danger')
        print("c2=", reset_email)
        return redirect(url_for('form_reset'))
    cur.close()
    return redirect(url_for('form_reset'))


@app.route('/form_reset', methods=['POST', 'GET'])
def form_reset():
    form = ResetForm()
    form.validate_on_submit()
    if request.method == 'POST':
        # if request.method == 'POST' and form.validate():
        email = request.form["email"]
        print("email-id=", email)
    return render_template('reset.html', form=form)


@app.route('/password_confirm', methods=['GET', 'POST'])
def password_confirm():
    form = PasswordForm()
    form.validate_on_submit()
    print("d1=", reset_email)
    if request.method == 'POST':
        # email = request.form['email']
        print("d2=", reset_email)
        if request.form["password"] != request.form["conf_pass"]:
            flash('Your password and confirm password values dont match!!', 'danger')
            print("d3=", reset_email)
        else:
            password = request.form['password']
            conf_pass = request.form['conf_pass']
            print(password, conf_pass)
            # print(session['email'])
            password_enc = sha256_crypt.encrypt(str(password))
            cursor = mysql.connection.cursor()
            print("d4=", reset_email)
            sql = "UPDATE `users` SET `password`=%s WHERE email= %s "
            val = (password_enc, reset_email)
            cursor.execute(sql, val)
            mysql.connection.commit()
            flash('Password Updated Successfully!', 'success')
            print("d5=", reset_email)
            return redirect(url_for('login'))
    return render_template('password_Reset.html', form=form)


@app.route('/reset', methods=['POST', 'GET'])
def reset():
    form = PasswordForm()
    form.validate_on_submit()
    global reset_email
    if request.method == 'POST':
        reset_email = request.form['email']
        if reset_email == '':
            print('email not entered', 'danger')
            flash('Email not Entered, Enter email', 'danger')
            return redirect(url_for('form_reset'))
        else:
            print('Email entered')
            # flash('Email captured')
        print(reset_email)
        cursor = mysql.connection.cursor()
        # cursor = db.cursor(buffered=True)
        sql = "SELECT * FROM users WHERE email=%s"
        val = (reset_email,)
        cursor.execute(sql, val)
        users = cursor.fetchone()
        if users:
            # session['email'] = reset_email
            print(uuid.uuid4().hex.upper())
            token = uuid.uuid4().hex.upper()
            sql2 = "INSERT INTO `token`(`token`, `email`) VALUES (%s,%s)"
            val2 = (token, reset_email)
            cursor.execute(sql2, val2)
            mysql.connection.commit()

            msg = Message(subject='Password Reset', sender='braintumordetectorapp@gmail.com',
                          recipients=[request.form['email']])
            link = url_for('conf_email', token=token, _external=True)
            print("a=", reset_email)
            msg.body = render_template('sentmail.html', token=token, link=link)
            mail.send(msg)

            flash('Reset password link sent to your Email !!', 'success')
            # print("checking for real")
            return redirect(url_for('login'))
        else:

            msg = Message(subject='Password Reset', sender='braintumordetectorapp@gmail.com',
                          recipients=[request.form['email']])
            msg.body = "This email is not registered in our tumor detection system!  " \
                       "Please Note: If you are not the one who entered this mail-id, please ignore this message!!"
            mail.send(msg)
            flash('This email is not registered with us. Enter the correct registered Email-id only!!', 'danger')
            # return redirect(url_for('login'))
            return render_template('reset.html', form=form)

    return render_template('login.html', form=form)


# @app.route('/conf_email/<token>/<email>')
@app.route('/conf_email/<token>')
def conf_email(token):
    try:
        token2 = token
        email2 = reset_email
    except SignatureExpired:
        return '<h1>The token is expired!</h1>'
    # return '<h1>The token works!</h1>'
    print("b=", email2)
    # return redirect(url_for('pass_form', token=token2, email=email2))
    return redirect(url_for('pass_form', token=token2))


if __name__ == '__main__':
    app.run(debug=True)

app.secret_key = 'secret123'
